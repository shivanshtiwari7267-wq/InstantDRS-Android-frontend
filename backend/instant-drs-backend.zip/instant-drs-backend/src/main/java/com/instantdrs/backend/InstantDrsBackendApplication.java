package com.instantdrs.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstantDrsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstantDrsBackendApplication.class, args);
	}

}
