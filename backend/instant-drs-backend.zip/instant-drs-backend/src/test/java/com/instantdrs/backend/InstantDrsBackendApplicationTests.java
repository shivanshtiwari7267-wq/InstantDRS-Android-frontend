package com.instantdrs.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstantDrsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
